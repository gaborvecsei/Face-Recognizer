# Input Image

Here you can store the training data in sub-folders.

The name of the sub-folder should be the person's name!