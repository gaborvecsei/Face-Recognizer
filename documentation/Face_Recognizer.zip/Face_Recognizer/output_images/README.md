# Output Image (training data)

Here you can find the prepared data for the training in sub-folders.

Every sub-folder belongs to one person