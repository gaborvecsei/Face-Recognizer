# Documentation

This folder contains my thesis in Hungarian language and a few images from the application.